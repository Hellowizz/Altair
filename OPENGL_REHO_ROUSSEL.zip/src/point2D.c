#include "point2D.h"

Point2D pointXY(float x, float y)
{
    Point2D p;
    p.x = x;
    p.y = y;
    return p;
}
