#ifndef POINT2D_H_
#define POINT2D_H_

typedef struct
{
    float x, y;
} Point2D;

Point2D pointXY(float x, float y);

#endif
